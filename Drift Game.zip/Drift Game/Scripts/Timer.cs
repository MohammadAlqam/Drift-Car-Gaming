﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class timer : MonoBehaviour
{

    public  float timeStart = 25;
    public  Text textBox;
    public  Text textCoin;
    public int coin = 100;
    public  int x = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (x==1){
          timeStart -= Time.deltaTime;
         textBox.text = Mathf.Round(timeStart).ToString();
        }
        textCoin.text=coin.ToString();
    }

    void OnTriggerEnter(Collider other){
         
        if (other.tag =="del1" && other.GetComponent<Collider>().enabled== true){
            //timer t = new timer();
            textBox.text = timeStart.ToString();
            x = 1;
            
           // timeStart = Time.time;
          
        }
        
        
         else if (other.CompareTag("del1-end") && other.GetComponent<Collider>().enabled== true){
            textBox.text = " ";
            x = 0;
            coin+=20/2;
           // timeStart = Time.time;
          
        }else if (other.tag=="del2" && other.GetComponent<Collider>().enabled== true){
            textBox.text = timeStart.ToString();
            x = 1;
            timeStart = 30;
        }else if (other.CompareTag("del2-end") && other.GetComponent<Collider>().enabled== true){
            textBox.text = " ";
            x = 0;
            coin+=30/2;
           // timeStart = Time.time;
          
        }
        
    }
}
