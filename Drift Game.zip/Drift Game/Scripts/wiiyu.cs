﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wiiyu : MonoBehaviour
{
        public GameObject preObject;

        

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        preObject.SetActive (false);
    }
}
