﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class wiim : MonoBehaviour
{
   public GameObject obj;
   public  bool s = true;

    // Update is called once per frame
    void Update()
    {
        if (s == true){
               setTrue(obj);
        }
        if (s== false)
        {
           setFalse(obj);
            
        }
    }
    void setTrue(GameObject o){
        o.GetComponent<Renderer>().enabled= true;
    }

    void setFalse(GameObject o){
        o.GetComponent<Renderer>().enabled= false;
    }
}
