﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class checkpoint2 : MonoBehaviour
{
   public GameObject checkpoint;
   public GameObject cube;

   void OnTriggerEnter(Collider other){
       if(other.gameObject.tag == "player")
       Destroy(checkpoint);
       Destroy(gameObject);
       Destroy(cube);
   }
}
