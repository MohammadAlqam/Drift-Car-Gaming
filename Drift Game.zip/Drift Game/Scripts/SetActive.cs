﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class setActive : MonoBehaviour
{
        [SerializeField] public GameObject nextObject;
        [SerializeField] public GameObject preObject;
        public bool a = true;

void Start(){
      if (a == false){
      preObject.GetComponent<Renderer>().enabled= false;
      } else {
      preObject.GetComponent<Renderer>().enabled= true;
      }
}
      void OnTriggerEnter(Collider other){
        if(other.CompareTag("Player") && preObject.GetComponent<Renderer>().enabled== true){
       preObject.GetComponent<Renderer>().enabled= false;
       nextObject.GetComponent<Renderer>().enabled= true;
       a = true;
        }
    }

    void Update()
    {
  
    //   if (a == true){
    //     preObject.GetComponent<Renderer>().enabled= true;
    //     print("test1");
    // }else {
    //     preObject.GetComponent<Renderer>().enabled= false;
    //     print("test2");
    // }
    }


}
